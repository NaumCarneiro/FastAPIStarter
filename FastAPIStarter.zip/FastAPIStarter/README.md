# 🔐 Escala de Vigilante - Controle Financeiro

Aplicação web completa de controle financeiro para vigilantes e qualquer pessoa que queira gerenciar suas despesas.

## 🚀 Características

✅ **Login Duplo:**
- Login primário para usuários
- Login secreto (admin) com ícone 🔒

✅ **Gerenciamento de Despesas:**
- Adicionar despesas com categoria, local, data e valor
- **Repetição automática** de gastos (até 120 meses)
- Histórico mensal navegável

✅ **Rendas:**
- Registrar salários, freelances, aluguéis, investimentos
- Rastreamento de renda ativa e passiva

✅ **Resumo Financeiro:**
- Gráficos e estatísticas
- Percentual de gastos por categoria
- Comparação renda vs gastos

✅ **Segurança:**
- Autenticação com JWT
- Senhas criptografadas com bcrypt
- Dados isolados por usuário

## 📋 Credenciais Padrão

### Login Secreto (Admin)
```
Usuário: NaumJMC
Senha: Jeci2002
```

### Acesso ao Painel Admin
Clique no ícone **🔒** (cadeado) no canto inferior direito da tela de login.

## 🛠️ Tecnologias

- **Frontend**: HTML5 + CSS3 + JavaScript Vanilla
- **Backend**: FastAPI (Python)
- **Banco de Dados**: SQLite (desenvolvimento) / PostgreSQL (produção)
- **Autenticação**: JWT + bcrypt

## 📥 Como Usar

### Online (Replit)
1. Acesse: https://seu-replit-link (configurar após deploy)
2. Faça login ou crie um usuário via painel admin

### Local
```bash
# 1. Clone o repositório
git clone https://github.com/seu-usuario/escala-vigilante.git
cd escala-vigilante

# 2. Instale as dependências
cd backend
pip install -r requirements.txt

# 3. Execute o servidor
python -m uvicorn main:app --host 0.0.0.0 --port 5000

# 4. Acesse em http://localhost:5000
```

## 📂 Estrutura do Projeto

```
.
├── backend/
│   ├── main.py                 # API FastAPI
│   ├── models.py              # Modelos SQLAlchemy
│   ├── database.py            # Configuração do banco
│   ├── static/
│   │   └── index.html         # Frontend
│   └── requirements.txt        # Dependências Python
├── README.md
└── .gitignore
```

## 🔧 Configuração de Ambiente

### Para PostgreSQL (Produção)
```bash
# Defina a variável de ambiente
export DATABASE_URL="postgresql://user:password@host/database"
```

### Segurança
⚠️ **IMPORTANTE:** Antes de usar em produção:
1. Altere `MASTER_USERNAME` e `MASTER_PASSWORD`
2. Altere `JWT_SECRET` para uma chave aleatória forte
3. Use variáveis de ambiente em vez de .env

## 📊 Funcionalidades Detalhadas

### Despesas com Repetição
- Registre uma despesa e marque "Repetir este gasto"
- Digite quantos meses (ex: 12 para compras em 12x)
- App cria automaticamente as parcelas

### Resumo Mensal
- Navegue entre meses (até 2030)
- Veja o total de gastos
- Compare com sua renda

### Administração
Clique no 🔒 para:
- Criar novos usuários
- Editar perfis
- Ver logs de auditoria

## 🚀 Deploy

### Replit
1. Acesse https://replit.com
2. Clique "Import from GitHub"
3. Cole a URL deste repositório
4. Clique em "Run"

### Outras Plataformas
Compatível com: Heroku, Railway, Render, AWS, Google Cloud

## 📝 Licença

Este projeto é de código aberto. Sinta-se livre para usar e modificar.

## 📧 Suporte

Dúvidas ou sugestões? Abra uma issue no GitHub!

---

**Desenvolvido por:** Seu Nome
**Data:** Novembro 2025
**Versão:** 1.0.0
