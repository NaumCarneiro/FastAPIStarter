# Aplicação de Controle Financeiro

## Visão Geral
Aplicação de controle financeiro para vigilantes com React Native/Expo (frontend mobile) e FastAPI + PostgreSQL (backend).

## Arquitetura do Projeto

### Backend (FastAPI + PostgreSQL)
- **Localização**: `/backend`
- **Tecnologias**: FastAPI, SQLAlchemy, PostgreSQL, JWT, bcrypt
- **Porta**: 8000
- **Principais funcionalidades**:
  - Sistema de autenticação dual (usuários primários + master/admin)
  - CRUD de despesas, receitas, dívidas e cartões de crédito
  - Sistema de gamificação com pontos e streaks
  - Log de auditoria para ações administrativas
  - Gerenciamento de usuários (admin)

### Frontend (React Native + Expo)
- **Localização**: `/frontend`
- **Tecnologias**: React Native, Expo Router, AsyncStorage, Axios
- **Porta**: (Expo Metro Bundler)
- **Telas implementadas**:
  - Login de usuários
  - Login master/admin
  - Perfil do usuário
  - Dashboard principal
  - Adicionar despesas
  - Painel administrativo

## Estrutura de Banco de Dados (PostgreSQL)

### Tabelas Principais:
- `users`: Usuários primários do sistema
- `master_users`: Usuários master/admin
- `expenses`: Registro de despesas
- `income`: Registro de receitas
- `debts`: Registro de dívidas
- `credit_cards`: Cartões de crédito
- `gamification`: Sistema de gamificação
- `audit_log`: Log de auditoria

## Credenciais Master Padrão
- **Usuário**: NaumJMC
- **Senha**: Jeci2002

⚠️ **IMPORTANTE - SEGURANÇA**:
- **ANTES DE USAR EM PRODUÇÃO**:
  1. Copie `backend/.env.example` para `backend/.env`
  2. Altere `MASTER_USERNAME` e `MASTER_PASSWORD` para valores seguros
  3. Altere `JWT_SECRET` para uma chave aleatória forte
  4. Nunca commite o arquivo `.env` ao repositório (já está no .gitignore)
- As credenciais padrão são apenas para desenvolvimento local
- Em produção, use secrets/variáveis de ambiente da Replit

## Configuração de Ambiente

### Backend (.env)
- `DATABASE_URL`: URL do PostgreSQL (automático via Replit)
- `JWT_SECRET`: Secret para tokens JWT

### Frontend (.env)
- `EXPO_PUBLIC_BACKEND_URL`: URL do backend (http://localhost:8000)

## Como Executar

### Backend
```bash
cd backend
python main.py
```

### Frontend
```bash
cd frontend
npm start
```

## Alterações Recentes
- 2025-11-15: Criação inicial do projeto
  - Configuração do backend FastAPI com PostgreSQL
  - Implementação de autenticação JWT
  - Criação de todos os endpoints da API
  - Implementação do frontend React Native com Expo
  - Sistema de gamificação implementado
